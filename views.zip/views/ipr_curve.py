import streamlit as st

st.title("IPR Curve")