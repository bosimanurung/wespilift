import streamlit as st

st.title("Data Input")